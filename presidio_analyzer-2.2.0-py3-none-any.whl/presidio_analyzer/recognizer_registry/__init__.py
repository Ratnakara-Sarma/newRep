"""Recognizer registry init."""
from .recognizer_registry import RecognizerRegistry

__all__ = ["RecognizerRegistry"]
