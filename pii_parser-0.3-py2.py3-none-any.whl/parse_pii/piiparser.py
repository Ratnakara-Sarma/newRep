import os
import spacy
import pandas as pd
from presidio_analyzer import AnalyzerEngine
from presidio_analyzer.nlp_engine import SpacyNlpEngine
from presidio_analyzer.recognizer_registry import RecognizerRegistry

import warnings
warnings.filterwarnings("ignore")


def entity_counter(entity_list):
    freq = {}
    entity_list = sorted(entity_list)
    for items in entity_list: 
        freq[items] = entity_list.count(items) 

    counter = ""
    for key, value in freq.items(): 
        if key == entity_list[-1]:
            counter += f"{key}:{value}"
        else:
            counter += f"{key}:{value}"+", "
    return counter


nlp = SpacyNlpEngine({"en": "en_core_web_lg"})
analyzer = AnalyzerEngine(nlp_engine=nlp)


def classify(text="",**kwargs):
    '''
        Classify text from a file or pass the text directly to the function.

        Examples:
        Passing a file:
            classify(path = "D:\\examples\\text_files\\", fileName = "sample_file.txt")
        Passing text
            classify(text = "some_text")
                or
            classify("some_text")

    '''
    # global nlp
    if "path" in kwargs and "fileName" in kwargs:
        with open(os.path.join(kwargs["path"],kwargs["fileName"])) as open_file:
            text = open_file.read()
            # print(text)
            response = analyzer.analyze(correlation_id=0,text = text,entities=[],language='en')
            if len(response) == 0:
                return "no"
            else:
                return "yes"
    elif text:
        text = text
        response = analyzer.analyze(correlation_id=0,text = text,entities=[],language='en')
        if len(response) == 0:
            return "no"
        else:
            return "yes"
    else:
        raise Exception("Parameters missing. Pass some text or path & file name as parameters. use help(classify) to see examples")


def extract(text="",**kwargs):
    '''
        Extract PII data from a file or pass the text directly to the function.

        Examples:
        Passing a file:
            extract(path = "D:\\examples\\text_files\\", fileName = "sample_file.txt")
        Passing text
            extract(text = "some_text")
                or
            extract("some_text")

    '''
    # global nlp

    if "path" in kwargs and "fileName" in kwargs:
        with open(os.path.join(kwargs["path"],kwargs["fileName"])) as open_file:
            text = open_file.read()
            # print(text)
            response = analyzer.analyze(correlation_id=0,text = text,entities=[],language='en')
            predicted_entities = []
            for item in response:
                predicted_entities.append(item.entity_type)
            if len(predicted_entities) == 0:
                return "No PII found"
            else:
                return str(entity_counter(predicted_entities))
    elif text:
        text = text
        response = analyzer.analyze(correlation_id=0,text = text,entities=[],language='en')
        predicted_entities = []
        for item in response:
            predicted_entities.append(item.entity_type)
        if len(predicted_entities) == 0:
            return "No PII found"
        else:
            return str(entity_counter(predicted_entities))        
    else:
        raise Exception("Parameters missing. Pass some text or path & file name as parameters. use help(classify) to see examples")
